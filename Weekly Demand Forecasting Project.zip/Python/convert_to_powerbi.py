import pandas as pd

# Load existing predictions
pred = pd.read_csv("weekly_predictions_next_4_weeks.csv", index_col=0)

# Reset index to get week as a column
pred.reset_index(inplace=True)
pred.rename(columns={'index':'Week'}, inplace=True)

# Melt into long format
long_pred = pred.melt(id_vars=['Week'], var_name='State', value_name='Forecast')

# Save reshaped CSV
long_pred.to_csv("weekly_predictions_long.csv", index=False)
print(long_pred)
