import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor

# --- Load CSV ---
df = pd.read_csv("dataset_tk.csv")
df.rename(columns={df.columns[0]: 'datetime'}, inplace=True)
df['datetime'] = pd.to_datetime(df['datetime'], dayfirst=True)
df.set_index('datetime', inplace=True)

# --- Fill missing values ---
df.fillna(method='ffill', inplace=True)  # forward fill
df.fillna(method='bfill', inplace=True)  # backward fill just in case

# --- Ensure non-negative values ---
df[df < 0] = 0

# --- Resample weekly ---
weekly_df = df.resample('W').sum()

# --- Create lag features for each state ---
def create_lag_features(data, lags=[1,2,3]):
    df_lag = data.copy()
    for col in data.columns:
        for lag in lags:
            df_lag[f'{col}_lag_{lag}'] = df_lag[col].shift(lag)
    df_lag.dropna(inplace=True)
    return df_lag

weekly_lagged = create_lag_features(weekly_df)

# --- Predict next 4 weeks for all states ---
future_weeks = 4
predictions = pd.DataFrame(columns=weekly_df.columns)

for state in weekly_df.columns:
    feature_cols = [f'{state}_lag_1', f'{state}_lag_2', f'{state}_lag_3']
    state_data = weekly_lagged[[state] + feature_cols]
    X = state_data[feature_cols]
    y = state_data[state]

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)

    # Iterative prediction
    last_row = X.iloc[-1].values.reshape(1,-1)
    state_preds = []
    for i in range(future_weeks):
        pred = model.predict(last_row)[0]
        # Ensure no negative predictions
        pred = max(pred, 0)
        state_preds.append(pred)
        last_row = np.roll(last_row, shift=1)
        last_row[0,0] = pred
    predictions[state] = state_preds

predictions.index = [f"Week {i+1}" for i in range(future_weeks)]
print(predictions.round(2))

# Save predictions
predictions.to_csv("weekly_predictions_next_4_weeks.csv")
